package dev.xkmc.l2magic.content.engine.core;

import com.mojang.serialization.Codec;
import dev.xkmc.l2magic.content.engine.context.EngineContext;
import dev.xkmc.l2magic.content.engine.selector.SelectedEntities;
import dev.xkmc.l2magic.content.engine.selector.SelectionType;
import dev.xkmc.l2magic.init.registrate.EngineRegistry;
import net.minecraft.world.level.Level;

public interface EntitySelector<T extends Record & EntitySelector<T>> extends Verifiable {

	Codec<EntitySelector<?>> CODEC = EngineRegistry.SELECTOR.codec()
			.dispatch(EntitySelector::type, SelectorType::codec);

	SelectorType<T> type();

	SelectedEntities find(Level level, EngineContext ctx, SelectionType type);

}
