package dev.xkmc.l2magic.content.engine.selector;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.xkmc.l2magic.content.engine.context.EngineContext;
import dev.xkmc.l2magic.content.engine.core.EntitySelector;
import dev.xkmc.l2magic.content.engine.core.SelectorType;
import dev.xkmc.l2magic.content.engine.variable.DoubleVariable;
import dev.xkmc.l2magic.content.engine.variable.IntVariable;
import dev.xkmc.l2magic.init.registrate.EngineRegistry;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public record ArcCubeSelector(
		IntVariable step,
		DoubleVariable radius,
		DoubleVariable size,
		DoubleVariable minAngle,
		DoubleVariable maxAngle
) implements EntitySelector<ArcCubeSelector> {

	public static final MapCodec<ArcCubeSelector> CODEC = RecordCodecBuilder.mapCodec(i -> i.group(
			IntVariable.codec("step", ArcCubeSelector::step),
			DoubleVariable.codec("radius", ArcCubeSelector::radius),
			DoubleVariable.codec("size", ArcCubeSelector::size),
			DoubleVariable.optionalCodec("minAngle", ArcCubeSelector::minAngle),
			DoubleVariable.optionalCodec("maxAngle", ArcCubeSelector::maxAngle)
	).apply(i, (s, r, x, c, d) -> new ArcCubeSelector(s, r, x,
			c.orElse(DoubleVariable.of("-180")),
			d.orElse(DoubleVariable.of("180"))
	)));

	@Override
	public SelectorType<ArcCubeSelector> type() {
		return EngineRegistry.ARC.get();
	}

	public SelectedEntities find(Level level, EngineContext ctx, SelectionType type) {
		Vec3 pos = ctx.loc().pos();
		int step = step().eval(ctx);
		double r = radius().eval(ctx);
		double diam = size.eval(ctx);
		double a0 = minAngle().eval(ctx);
		double a1 = maxAngle().eval(ctx);
		var ori = ctx.loc().ori();
		SelectedEntities list = new SelectedEntities();
		for (int i = 0; i <= step; i++) {
			double a = a0 + (a1 - a0) / step * i;
			Vec3 p = pos.add(ori.rotateDegrees(a).scale(r));
			var aabb = AABB.ofSize(p, diam, diam, diam);
			type.collect(level, ctx, aabb, list);
		}
		return list;
	}

}
